import React, { Component } from "react";
import CarouselBox from "./CarouselBox";



export default class Main extends Component {
  render() {
    return (
      <CarouselBox />
    )
  }
}